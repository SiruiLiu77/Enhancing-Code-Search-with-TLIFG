import pickle
import torch.nn as nn
import torch
import math
import torch.nn.functional as F
from torch.autograd import Variable

from config import config
from making_vocab import DescVocab, CodeVocab, ASTVocab
import os
import torch.utils.data as data

"""
tl-ifg transformer
"""

# torch.set_printoptions(profile="full")

class Embedding(nn.Module):
    def __init__(self, emb, emb_size, init=True):
        super(Embedding, self).__init__()

        self.embedding = nn.Embedding(emb.size(0), emb_size, padding_idx=0)

        if init:
            assert emb.size(1) == emb_size
            emb[0] = torch.zeros(emb_size)
            self.embedding.weight = torch.nn.Parameter(emb)

    def forward(self, x):
        """
        :param x: [batch size, seq len]
        :return: [batch size, seq len, emb size]
        """
        embedded = self.embedding(x) # [batch size, seq len, emb size]
        return embedded

class LayerNorm(nn.Module):
    def __init__(self, hidden_size, eps=1e-12):
        super(LayerNorm, self).__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.bias = nn.Parameter(torch.zeros(hidden_size))
        self.variance_epsilon = eps

    def forward(self, x):
        """
        :param x: [batch size, seq len, hidden size]
        :return: [batch size, seq len, hidden size]
        """
        u = x.mean(-1, keepdim=True)
        s = (x - u).pow(2).mean(-1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.variance_epsilon)
        return self.weight * x + self.bias # [batch size, seq len, hidden size]

class GraphAttentionLayer(nn.Module):
    def __init__(self, in_features, out_features, dropout, alpha, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha
        self.concat = concat

        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data)
        self.a1 = nn.Parameter(torch.zeros(size=(out_features, 1)))
        nn.init.xavier_uniform_(self.a1.data)
        self.a2 = nn.Parameter(torch.zeros(size=(out_features, 1)))
        nn.init.xavier_uniform_(self.a2.data)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, inp, adj):
        """
        :param inp: [batch size, ast len, in features]
        :param adj: [batch size, ast len, ast len]
        :return: [batch size, ast len, out features]
        """
        N = inp.size()[1]

        h = torch.matmul(inp, self.W) # [batch size, N, out features]
        ''' h: [[h1], [h2], ..., [hN]], ...'''

        a_input1 = torch.matmul(h, self.a1).repeat(1, 1, N) # [batch size, N, N]
        a_input2 = torch.matmul(h, self.a2).permute(0, 2, 1).repeat(1, N, 1) # [batch size, N, N]
        a_input = a_input1 + a_input2

        e = self.leakyrelu(a_input) # [batch size, N, N]
        zero_vec = -1e12 * torch.ones_like(e) # [batch size, N, N]
        adj = adj + torch.eye(adj.size(-1)).unsqueeze(0).repeat(adj.size(0), 1, 1).to(adj.device)
        attention = (1 - adj) * zero_vec + adj * e # [batch size, N, N]
        # attention = torch.where(adj>0, e, zero_vec) # [batch size, N, N]
        attention = F.softmax(attention, dim=-1)
        attention = F.dropout(attention, self.dropout, training=self.training)

        h_prime = torch.matmul(attention, h) # [batch size, N, out features]

        if self.concat:
            return nn.ReLU(inplace=True)(h_prime)
        else:
            return h_prime

class GAT(nn.Module):
    def __init__(self, input_size, dropout, alpha, n_layers):
        super(GAT, self).__init__()
        self.dropout = dropout

        self.attentions = nn.ModuleList([GraphAttentionLayer(input_size, input_size, dropout=dropout, alpha=alpha, concat=True) for _ in range(n_layers)])
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)
        self.out_att = GraphAttentionLayer(input_size, input_size, dropout=dropout, alpha=alpha, concat=False)

        # self.dense = nn.Linear(hidden_size, hidden_size)
        self.LayerNorm = LayerNorm(input_size)

    def forward(self, x, adj):
        """
        :param x: [batch size, ast len, input size]
        :param adj: [batch size, ast len, ast len]
        :return: [batch size, ast len, hidden size]
        """
        for att in self.attentions:
            x = att(x, adj) # [batch size, N, input size]
        x = nn.ReLU(inplace=True)(self.out_att(x, adj)) # [batch size, N, input size]
        x = F.log_softmax(x, dim=-1)

        # x = self.dense(x)  # [batch size, N, input size]
        x = self.LayerNorm(x) # [batch size, N, input size]
        x = F.dropout(x, self.dropout, training=self.training)



        return x # [batch size, N, input size]

class SelfAttention(nn.Module):
    def __init__(self, input_size, dropout):
        super(SelfAttention, self).__init__()

        self.input_size = input_size

        self.query = nn.Linear(input_size, input_size)
        self.key = nn.Linear(input_size, input_size)

        # self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        """
        :param x: [batch size, seq len, input size]
        :return: [batch size, seq len, seq len]
        """
        margin = 1 / x.size(1) * 0.5

        seq_len = x.size(1)
        # margin = 1 / seq_len

        query_layer = self.query(x)  # [batch size, seq len, input size]
        key_layer = self.key(x)

        attention_mask = torch.matmul(x, x.transpose(-1, -2))
        attention_mask = torch.where(attention_mask != 0, torch.zeros_like(attention_mask), -1e12*torch.ones_like(attention_mask))
        # print(attention_mask.mean())

        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1,-2))  # [batch size, seq len, seq len]
        attention_scores = attention_scores / math.sqrt(self.input_size) + attention_mask
        # print(attention_scores)

        attention_scores = nn.Softmax(dim=-1)(attention_scores)
        attention_mask = torch.where(attention_mask == 0, torch.ones_like(attention_mask), torch.zeros_like(attention_mask))
        attention_scores = attention_scores * attention_mask

        attention_scores = torch.where(attention_scores > margin, torch.ones_like(attention_scores), torch.zeros_like(attention_scores))
        # attention_scores = torch.where(attention_scores > margin, attention_scores, torch.zeros_like(attention_scores))
        # attention_mask = torch.where(attention_scores != 0, torch.zeros_like(attention_scores), -1e12*torch.ones_like(attention_scores))
        # attention_scores = attention_scores + attention_mask
        # attention_scores = nn.Softmax(dim=-1)(attention_scores)


        # attention_scores = self.dropout(attention_scores)

        return attention_scores

class SequenceEmbedding(nn.Module):
    def __init__(self, input_size, n_layers):
        super(SequenceEmbedding, self).__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=input_size, nhead=1, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=n_layers)

    def forward(self, x, attention_scores):
        """
        :param x: [batch size, seq len, input size]
        :param attention_scores: [batch size, seq len, seq len] (0-1 matrix)
        :return: [batch size, seq len, input size], [batch size, input size]
        """
        # attention_scores = 1 - attention_scores
        # attention_scores = attention_scores.bool()

        attention_scores = torch.where(attention_scores == 1, torch.zeros_like(attention_scores), -1e12*torch.ones_like(attention_scores))
        # attention_scores = torch.where(attention_scores > 0, 0.1*attention_scores, -1e12 * torch.ones_like(attention_scores))

        output = self.transformer_encoder(x, mask=attention_scores) # [batch size, seq len, input size]
        cls = output[:, 0, :] # [batch size, input size]

        return output, cls

class SequenceEmbeddingWoGraph(nn.Module):
    def __init__(self, input_size, n_layers):
        super(SequenceEmbeddingWoGraph, self).__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=input_size, nhead=1, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=n_layers)

    def forward(self, x):
        """
        :param x: [batch size, seq len, input size]
        :return: [batch size, seq len, input size], [batch size, input size]
        """
        output = self.transformer_encoder(x) # [batch size, seq len, input size]
        cls = output[:, 0, :] # [batch size, input size]

        return output, cls

class Interact(nn.Module):
    def __init__(self, hidden_size, dropout):
        super(Interact, self).__init__()
        self.hidden_size = hidden_size

        self.qa = nn.Linear(hidden_size, hidden_size)
        self.ka = nn.Linear(hidden_size, hidden_size)
        self.qb = nn.Linear(hidden_size, hidden_size)
        self.kb = nn.Linear(hidden_size, hidden_size)

        self.dropout = nn.Dropout(dropout)

    def forward(self, a, b):
        """
        :param a: [batch size, len a, hidden size]
        :param b: [batch size, len b, hidden size]
        :return: [batch size, hidden size], [batch size, hidden size]
        """
        qa = self.qa(a) # [batch size, len a, hidden size]
        ka = self.ka(a) # [batch size, len a, hidden size]
        qb = self.qb(b) # [batch size, len b, hidden size]
        kb = self.kb(b) # [batch size, len b, hidden size]

        attention_scores_ab = torch.matmul(qa, kb.transpose(-1, -2)) # [batch size, len a, len b]
        attention_scores_ab = attention_scores_ab / math.sqrt(self.hidden_size)
        attention_scores_ab = nn.Softmax(dim=-1)(attention_scores_ab)
        attention_scores_ab = self.dropout(attention_scores_ab)
        attention_scores_ab = torch.sum(attention_scores_ab, dim=1) # [batch size, len b]
        attention_scores_ab = nn.Softmax(dim=-1)(attention_scores_ab) # [batch size, len b]
        attention_scores_ab = attention_scores_ab.unsqueeze(1) # [batch size, 1, len b]
        hs_b = torch.matmul(attention_scores_ab, b).squeeze(1) # [batch size, 1, hidden size]

        attention_scores_ba = torch.matmul(qb, ka.transpose(-1, -2)) # [batch size, len b, len a]
        attention_scores_ba = attention_scores_ba / math.sqrt(self.hidden_size)
        attention_scores_ba = nn.Softmax(dim=-1)(attention_scores_ba)
        attention_scores_ba = self.dropout(attention_scores_ba)
        attention_scores_ba = torch.sum(attention_scores_ba, dim=1) # [batch size, len a]
        attention_scores_ba = nn.Softmax(dim=-1)(attention_scores_ba) # [batch size, len a]
        attention_scores_ba = attention_scores_ba.unsqueeze(1) # [batch size, 1, len a]
        hs_a = torch.matmul(attention_scores_ba, a).squeeze(1) # [batch size, hidden size]

        return hs_a, hs_b

class Fusion(nn.Module):
    def __init__(self, hidden_size, output_size, dropout):
        super(Fusion, self).__init__()
        self.output_size = output_size

        self.W_code = nn.Linear(hidden_size, output_size)
        self.W_desc = nn.Linear(hidden_size, output_size)

        self.dropout = nn.Dropout(dropout)

    def get_code_vec(self, rnn_vec, interact_vec):
        '''
        :param rnn_vec: [batch size, hidden size]
        :param interact_vec: [batch size, hidden size]
        :return: [batch size, output size]
        '''
        code_vec = rnn_vec + interact_vec # [batch size, hidden size]
        code_vec = nn.ReLU(inplace=True)(self.W_code(code_vec)) # [batch size, output size]
        return code_vec

    def get_desc_vec(self, rnn_vec, interact_vec):
        '''
        :param rnn_vec: [batch size, hidden size]
        :param interact_vec: [batch size, hidden size]
        :return: [batch size, output size]
        '''
        desc_vec = rnn_vec + interact_vec # [batch size, hidden size]
        desc_vec = nn.ReLU(inplace=True)(self.W_desc(desc_vec)) # [batch size, output size]
        return desc_vec

    def forward(self, code_rnn_vec, code_interact_vec, desc_rnn_vec, desc_interact_vec):
        '''
        :param code_rnn_vec: [batch size, hidden size]
        :param code_interact_vec: [batch size, hidden size]
        :param desc_rnn_vec: [batch size, hidden size]
        :param desc_interact_vec: [batch size, hidden size]
        :return: [batch size, output size], [batch size, output size]
        '''
        code_vec = self.get_code_vec(code_rnn_vec, code_interact_vec)
        desc_vec = self.get_desc_vec(desc_rnn_vec, desc_interact_vec)
        return code_vec, desc_vec # [batch size, output size], [batch size, output size]

class CodeSearchModel(nn.Module):
    def __init__(self, config):
        super(CodeSearchModel, self).__init__()
        emb_size = config['emb_size']
        # hidden_size = config['hidden_size']
        output_size = config['output_size']
        # ifg_emb_size = int(emb_size / 2)
        ifg_emb_size = emb_size
        num_attention_heads = config['num_attention_heads']
        gat_layer_num = config['gat_layer_num']
        rnn_layer_num = config['rnn_layer_num']
        dropout = config['dropout']
        alpha = config['alpha']

        self.ast_nonterm_len = config['ast_nonterm_len']
        self.margin = config['margin']
        self.loss_type = config['loss_type']

        desc_vocab = DescVocab(config)
        desc_vocab.load()
        code_vocab = CodeVocab(config)
        code_vocab.load()
        ast_vocab = ASTVocab(config)
        ast_vocab.load()

        word_emb = desc_vocab.word_emb
        token_emb = code_vocab.token_emb
        nonterm_emb = ast_vocab.nonterm_emb

        self.token_embedding_model = Embedding(token_emb, emb_size)
        self.word_embedding_model = Embedding(word_emb, emb_size)
        # self.nonterm_embedding_model = Embedding(nonterm_emb, ifg_emb_size, init=False)
        self.nonterm_embedding_model = Embedding(nonterm_emb, ifg_emb_size)

        self.ast_gat_model = GAT(ifg_emb_size, dropout, alpha, gat_layer_num)

        self.code_self_attn = SelfAttention(ifg_emb_size + emb_size, dropout) # ifg_emb_size
        self.desc_self_attn = SelfAttention(emb_size, dropout)

        self.code_seq_model = SequenceEmbedding(emb_size, rnn_layer_num)
        self.desc_seq_model = SequenceEmbedding(emb_size, rnn_layer_num)

        # self.interact_model = Interact(hidden_size, dropout)

        # self.fusion_model = Fusion(hidden_size, output_size, dropout)
        self.code_fusion_model = nn.Linear(emb_size, output_size)
        self.desc_fusion_model = nn.Linear(emb_size, output_size)

        self.cos = nn.CosineSimilarity(dim=1, eps=1e-6)

    def val_p1(self, c, n, nonterm_a, term_a, pos_d):
        """
        :param c: [batch size, seq len]
        :param n: [batch size, ast len]
        :param nonterm_a: [batch size, ast nonterm len, ast nonterm len]
        :param term_a: [batch size, ast term len, ast nonterm len]
        :param pos_d: [batch size, seq len]
        :return: [batch size, seq len, hidden size], [batch size, hidden size], [batch size, seq len, hidden size], [batch size, hidden size]
        """
        c = self.token_embedding_model(c)  # [batch size, seq len, emb size]
        pos_d = self.word_embedding_model(pos_d)  # [batch size, seq len, emb size]

        n = self.nonterm_embedding_model(n[:, : 1 + self.ast_nonterm_len])  # [batch size, 1 + ast nonterm len, emb size / 2]
        n_cls = n[:, 0, :].unsqueeze(1)  # [batch size, 1, emb size / 2]
        n = n[:, 1:, :]  # [batch size, ast nonterm len, emb size / 2]

        n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]
        n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]
        # n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]

        n = torch.matmul(term_a.float(), n)  # [batch size, ast term len, emb size / 2]
        n = torch.cat([n_cls, n], dim=1)  # [batch size, 1 + ast term len, emb size / 2]
        n = torch.cat([n, c], dim=-1)  # [batch size, seq len, emb size / 2 + emb size]

        c_attn = self.code_self_attn(n)  # [batch size, seq len, seq len]
        pos_d_attn = self.desc_self_attn(pos_d)  # [batch size, seq len, seq len]

        c_inter, c_cls = self.code_seq_model(c, c_attn)  # [batch size, seq len, hidden size], [batch size, hidden size]
        pos_d_inter, pos_d_cls = self.desc_seq_model(pos_d, pos_d_attn)  # [batch size, seq len hidden size], [batch size, hidden size]

        # c_inter, c_cls = self.code_seq_model(c)  # [batch size, seq len, hidden size], [batch size, hidden size]
        # pos_d_inter, pos_d_cls = self.desc_seq_model(pos_d)  # [batch size, seq len hidden size], [batch size, hidden size]

        return c_inter, c_cls, pos_d_inter, pos_d_cls

    def val_p2(self, c_inter, c_cls, pos_d_inter, pos_d_cls, i, pos_d):
        """
        :param c_inter: [batch size, seq len, hidden size]
        :param c_rnn: [batch size, hidden size]
        :param pos_d_inter: [batch size, seq len, hidden size]
        :param pos_d_rnn: [batch size, hidden size]
        :param i: scale
        :param pos_d: [batch size, seq len]
        :return: [batch size]
        """
        # pos_d_inter_single = pos_d_inter[i].unsqueeze(0).repeat(len(pos_d), 1, 1)
        pos_d_cls_single = pos_d_cls[i].unsqueeze(0).repeat(len(pos_d), 1)

        # c_inter, pos_d_inter_single = self.interact_model(c_inter, pos_d_inter_single)  # [batch size, hidden size], [batch size, hidden size]
        # code_vec, desc_vec = self.fusion_model(c_cls, c_inter, pos_d_cls_single, pos_d_inter_single)  # [batch size, output size], [batch size, output size]
        code_vec = self.code_fusion_model(c_cls) # [batch size, output size]
        desc_vec = self.desc_fusion_model(pos_d_cls_single) # [batch size, output size]

        if self.loss_type == 'cross_entropy':
            return code_vec, desc_vec

        pos_sims = self.cos(code_vec, desc_vec)  # [batch size]

        return pos_sims

    def forward(self, c, n, nonterm_a, term_a, pos_d, neg_d=None):
        """
        :param c: [batch size, seq len + 1]
        :param n: [batch size, ast len]
        :param nonterm_a: [batch size, ast nonterm len, ast nonterm len]
        :param term_a: [batch size, ast term len, ast nonterm len]
        :param pos_d: [batch size, seq len + 1]
        :param neg_d: [batch size, seq len + 1]
        :return:
        """
        c = self.token_embedding_model(c) # [batch size, seq len + 1, emb size]
        pos_d = self.word_embedding_model(pos_d) # [batch size, seq len + 1, emb size]

        n = self.nonterm_embedding_model(n[:, : 1 + self.ast_nonterm_len])  # [batch size, 1 + ast nonterm len, emb size / 2]
        n_cls = n[:, 0, :].unsqueeze(1) # [batch size, 1, emb size / 2]
        n = n[:, 1:, :] # [batch size, ast nonterm len, emb size / 2]

        n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]
        n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]
        # n = self.ast_gat_model(n, nonterm_a)  # [batch size, ast nonterm len, emb size / 2]

        n = torch.matmul(term_a.float(), n) # [batch size, ast term len, emb size / 2]
        n = torch.cat([n_cls, n], dim=1) # [batch size, 1 + ast term len, emb size / 2]
        n = torch.cat([n, c], dim=-1) # [batch size, seq len, emb size / 2 + emb size]

        c_attn = self.code_self_attn(n)  # [batch size, seq len, seq len]
        # print(c_attn.mean())
        pos_d_attn = self.desc_self_attn(pos_d)  # [batch size, seq len, seq len]

        c_inter, c_cls = self.code_seq_model(c, c_attn)  # [batch size, seq len, hidden size], [batch size, hidden size]
        # print(c_inter.mean())
        pos_d_inter, pos_d_cls = self.desc_seq_model(pos_d, pos_d_attn)  # [batch size, seq len hidden size], [batch size, hidden size]

        # c_inter, c_cls = self.code_seq_model(c)  # [batch size, seq len, hidden size], [batch size, hidden size]
        # pos_d_inter, pos_d_cls = self.desc_seq_model(pos_d)  # [batch size, seq len hidden size], [batch size, hidden size]

        # pos_c_inter, pos_d_inter = self.interact_model(c_inter, pos_d_inter)  # [batch size, hidden size], [batch size, hidden size]

        # pos_code_vec, pos_desc_vec = self.fusion_model(c_cls, pos_c_inter, pos_d_cls, pos_d_inter)  # [batch size, output size], [batch size, output size]
        pos_code_vec = self.code_fusion_model(c_cls) # [batch size, output size]
        pos_desc_vec = self.desc_fusion_model(pos_d_cls) # [batch size, output size]

        if neg_d == None and self.loss_type == 'cross_entropy':
            # print(pos_code_vec, pos_desc_vec)
            return pos_code_vec, pos_desc_vec

        pos_sim = self.cos(pos_code_vec, pos_desc_vec)  # [batch size]

        if neg_d is not None:
            neg_d = self.word_embedding_model(neg_d)  # [batch size, seq len, emb size]

            neg_d_attn = self.desc_self_attn(neg_d)  # [batch size, seq len, seq len]

            neg_d_inter, neg_d_cls = self.desc_seq_model(neg_d, neg_d_attn)  # [batch size, seq len hidden size], [batch size, hidden size]

            # neg_d_inter, neg_d_cls = self.desc_seq_model(neg_d)  # [batch size, seq len hidden size], [batch size, hidden size]

            # neg_c_inter, neg_d_inter = self.interact_model(c_inter, neg_d_inter)  # [batch size, hidden size], [batch size, hidden size]

            # neg_code_vec, neg_desc_vec = self.fusion_model(c_cls, neg_c_inter, neg_d_cls, neg_d_inter) # [batch size, output size], [batch size, output size]
            neg_code_vec = self.code_fusion_model(c_cls)
            neg_desc_vec = self.desc_fusion_model(neg_d_cls)
            neg_sim = self.cos(neg_code_vec, neg_desc_vec)  # [batch size]

            loss = (self.margin - pos_sim + neg_sim).clamp(min=1e-6) # [batch size]
            loss[loss < 0] = 0.0  # [batch size]
            loss = loss.mean()  # [1]

            return loss

        return pos_sim

# if __name__ == '__main__':
#     from dataset import CodeSearchDataSet
#     from torch.nn import CrossEntropyLoss
#
#     config = config()
#
#     trainset_save_path = os.path.join(config['tmp_dir'], 'trainset.h5')
#     trainset = CodeSearchDataSet(trainset_save_path, mode='train')
#     trainloader = data.DataLoader(dataset=trainset, batch_size=1020, shuffle=True, num_workers=4, pin_memory=True, prefetch_factor=2)
#
#     model = CodeSearchModel(config)
#     model = model.cuda()
#
#     for data in trainloader:
#         c, n, nonterm_a, term_a, pos_d, neg_d = data
#         c = c.cuda()
#         n = n.cuda()
#         nonterm_a = nonterm_a.cuda()
#         term_a = term_a.cuda()
#         pos_d = pos_d.cuda()
#         neg_d = neg_d.cuda()
#         break
#
#     code_vec, desc_vec = model(c, n, nonterm_a, term_a, pos_d)
#     scores = torch.einsum("ab,cb->ac", desc_vec, code_vec)
#     loss_fct = CrossEntropyLoss()
#     loss = loss_fct(scores, torch.arange(c.size(0), device=scores.device))
#
#     print(loss)