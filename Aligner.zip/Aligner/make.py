import os
import shutil
import random
import sys
import jsonlines
from tqdm import tqdm
from utils import *

def calculate(input_file, output_dir):
    output_file = os.path.join(output_dir, 'tmp.jsonl')
    with open(input_file, 'r') as f:
        print(f'Calculating: {input_file}')
        for item in tqdm(jsonlines.Reader(f), file=sys.stdout):
            docstring = item['docstring']
            code = item['code']

            doc_all, doc_fir = docstring_parsing(docstring)
            if doc_all is None or doc_fir is None:
                continue

            code_ast_wo_string, code_tok_seq_wo_string, code_subast_wo_string, code_subtok_seq_wo_string = code_parsing(code, reserve_string=False)
            if len(code_tok_seq_wo_string) == 0 or code_ast_wo_string is None or len(code_subtok_seq_wo_string) == 0 or code_subast_wo_string is None:
                continue

            code_ast_wi_string, code_tok_seq_wi_string, code_subast_wi_string, code_subtok_seq_wi_string = code_parsing(code, reserve_string=True)
            if len(code_tok_seq_wi_string) == 0 or code_ast_wi_string is None or len(code_subtok_seq_wi_string) == 0 or code_subast_wi_string is None:
                continue

            # assert doc_all is not None and doc_fir is not None
            #
            # result = {'doc_all': doc_all, 'doc_fir': doc_fir}

            assert doc_all is not None and doc_fir is not None \
                    and code_ast_wo_string is not None and code_tok_seq_wo_string is not None \
                    and code_subast_wo_string is not None and code_subtok_seq_wo_string is not None \
                    and code_ast_wi_string is not None and code_tok_seq_wi_string is not None \
                    and code_subast_wi_string is not None and code_subtok_seq_wi_string is not None

            result = {'doc_all': doc_all, 'doc_fir': doc_fir,
                      'code_ast_wo_string': code_ast_wo_string, 'code_tok_seq_wo_string': code_tok_seq_wo_string,
                      'code_subast_wo_string': code_subast_wo_string, 'code_subtok_seq_wo_string': code_subtok_seq_wo_string,
                      'code_ast_wi_string': code_ast_wi_string, 'code_tok_seq_wi_string': code_tok_seq_wi_string,
                      'code_subast_wi_string': code_subast_wi_string, 'code_subtok_seq_wi_string': code_subtok_seq_wi_string,
                      'raw_code': code, 'raw_doc': docstring}

            with jsonlines.open(output_file, 'a') as out:
                out.write(result)

def parsing(output_dir):
    tmp_file = os.path.join(output_dir, 'tmp.jsonl')

    os.makedirs(os.path.join(output_dir, 'test'))
    os.makedirs(os.path.join(output_dir, 'valid'))
    os.makedirs(os.path.join(output_dir, 'train'))

    total_num = 0
    with open(tmp_file, 'r') as f:
        for _ in tqdm(jsonlines.Reader(f), file=sys.stdout):
            total_num += 1

    sample_ids = random.sample(range(total_num), 10000)
    test_ids = sample_ids

    # sample_ids = random.sample(range(total_num), 78422)
    # test_ids = sample_ids[:8714]
    # train_ids = sample_ids[8714:]

    with open(tmp_file, 'r') as f:
        print('Parsing: ')
        for id, item in tqdm(enumerate(jsonlines.Reader(f)), file=sys.stdout):
            doc_all = item['doc_all']
            doc_fir = item['doc_fir']
            code_ast_wo_string = item['code_ast_wo_string']
            code_tok_seq_wo_string = item['code_tok_seq_wo_string']
            code_subast_wo_string = item['code_subast_wo_string']
            code_subtok_seq_wo_string = item['code_subtok_seq_wo_string']
            code_ast_wi_string = item['code_ast_wi_string']
            code_tok_seq_wi_string = item['code_tok_seq_wi_string']
            code_subast_wi_string = item['code_subast_wi_string']
            code_subtok_seq_wi_string = item['code_subtok_seq_wi_string']
            raw_code = item['raw_code']
            raw_doc = item['raw_doc']

            if id in test_ids:
                pattern = 'test'
            else:
                pattern = 'train'

            # if id in test_ids:
            #     pattern = 'test'
            # elif id in train_ids:
            #     pattern = 'train'
            # else:
            #     continue

            pattern_dir = os.path.join(output_dir, pattern)

            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_doc_all.jsonl'), 'a') as out_doc_all:
                out_doc_all.write(doc_all)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_doc_first.jsonl'), 'a') as out_doc_fir:
                out_doc_fir.write(doc_fir)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_ast_without_string.jsonl'), 'a') as out_code_ast_wo_string:
                out_code_ast_wo_string.write(code_ast_wo_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_token_sequence_without_string.jsonl'), 'a') as out_code_tok_seq_wo_string:
                out_code_tok_seq_wo_string.write(code_tok_seq_wo_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_sub_ast_without_string.jsonl'), 'a') as out_code_subast_wo_string:
                out_code_subast_wo_string.write(code_subast_wo_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_sub_token_sequence_without_string.jsonl'), 'a') as out_code_subtok_seq_wo_string:
                out_code_subtok_seq_wo_string.write(code_subtok_seq_wo_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_ast_with_string.jsonl'), 'a') as out_code_ast_wi_string:
                out_code_ast_wi_string.write(code_ast_wi_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_token_sequence_with_string.jsonl'), 'a') as out_code_tok_seq_wi_string:
                out_code_tok_seq_wi_string.write(code_tok_seq_wi_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_sub_ast_with_string.jsonl'), 'a') as out_code_subast_wi_string:
                out_code_subast_wi_string.write(code_subast_wi_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_sub_token_sequence_with_string.jsonl'), 'a') as out_code_subtok_seq_wi_string:
                out_code_subtok_seq_wi_string.write(code_subtok_seq_wi_string)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_code_raw.jsonl'), 'a') as out_raw_code:
                out_raw_code.write(raw_code)
            with jsonlines.open(os.path.join(pattern_dir, 'java_' + pattern + '_doc_raw.jsonl'), 'a') as out_raw_doc:
                out_raw_doc.write(raw_doc)

if __name__ == '__main__':
    output_dir = '/home/liusirui/EXPE/MakingData3/DataSetTreesitter'
    input_file_dir = '/home/liusirui/EXPE/MakingData3/CodeSearchNet/java/java/final/jsonl'

    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir)

    input_file_dir_train = os.path.join(input_file_dir, 'train')
    for i in range(16):
        input_file = os.path.join(input_file_dir_train, f'java_train_{i}.jsonl')
        calculate(input_file, output_dir)
    input_file_dir_valid = os.path.join(input_file_dir, 'valid')
    input_file = os.path.join(input_file_dir_valid, 'java_valid_0.jsonl')
    calculate(input_file, output_dir)
    input_file_dir_test = os.path.join(input_file_dir, 'test')
    input_file = os.path.join(input_file_dir_test, 'java_test_0.jsonl')
    calculate(input_file, output_dir)

    parsing(output_dir)