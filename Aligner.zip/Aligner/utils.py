import re
from io import StringIO
from nltk import tokenize
from tree_sitter import Language, Parser

Language.build_library(
    # Store the library in the `build` directory
    'build/my-languages.so',

    # Include one or more languages
    [
        '../tree-sitter-java'
    ]
)

JA_LANGUAGE = Language('build/my-languages.so', 'java')

parser = Parser()
parser.set_language(JA_LANGUAGE)

def extract_leaves_and_tokens(code):
    tokens = extract_code_wo_format(code)
    tokens = tokens.split()
    ast = parser.parse(bytes(code, "utf8"))
    root_node = ast.root_node
    vertexs = {}
    edges = []
    leaves_wi_idx = []
    traversing(root_node, 0, vertexs, edges, leaves_wi_idx)
    leaves = [leaves_wi_idx[i][0] for i in range(len(leaves_wi_idx))]
    return vertexs, edges, leaves, leaves_wi_idx, tokens

def traversing(root_node, idx, vertexs, edges, leaves_wi_idx):
    vertexs[idx] = root_node.type
    if len(root_node.children) == 0:
        leaves_wi_idx.append((root_node.type, idx))
        return
    else:
        for child in root_node.children:
            idx1 = len(vertexs)
            edges.append([idx, idx1])
            traversing(child, idx1, vertexs, edges, leaves_wi_idx)


def extract_code_wo_format(code):
    syms = re.findall(r'[^a-zA-Z0-9_$\u4e00-\u9fa5]', code)
    syms = list(set(syms))
    for sym in syms:
        code = code.replace(sym, ' ' + sym + ' ')
    code = code.split()
    code = ' '.join(code)

    return code.strip()


def remove_comments_and_docstrings(source, lang):
    if lang in ['python']:
        """
        Returns 'source' minus comments and docstrings.
        """
        io_obj = StringIO(source)
        out = ""
        prev_toktype = tokenize.INDENT
        last_lineno = -1
        last_col = 0
        for tok in tokenize.generate_tokens(io_obj.readline):
            token_type = tok[0]
            token_string = tok[1]
            start_line, start_col = tok[2]
            end_line, end_col = tok[3]
            ltext = tok[4]
            if start_line > last_lineno:
                last_col = 0
            if start_col > last_col:
                out += (" " * (start_col - last_col))
            # Remove comments:
            if token_type == tokenize.COMMENT:
                pass
            # This series of conditionals removes docstrings:
            elif token_type == tokenize.STRING:
                if prev_toktype != tokenize.INDENT:
                    # This is likely a docstring; double-check we're not inside an operator:
                    if prev_toktype != tokenize.NEWLINE:
                        if start_col > 0:
                            out += token_string
            else:
                out += token_string
            prev_toktype = token_type
            last_col = end_col
            last_lineno = end_line
        temp = []
        for x in out.split('\n'):
            if x.strip() != "":
                temp.append(x)
        return '\n'.join(temp)
    elif lang in ['ruby']:
        return source
    else:
        def replacer(match):
            s = match.group(0)
            if s.startswith('/'):
                return " "  # note: a space and not an empty string
            else:
                return s

        pattern = re.compile(
            r'//.*?$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"',
            re.DOTALL | re.MULTILINE
        )
        temp = []
        for x in re.sub(pattern, replacer, source).split('\n'):
            if x.strip() != "":
                temp.append(x)
        return '\n'.join(temp)


def aligning(leaves, leaves_wi_idx, tokens, reserve_string=False):
    tok_string = ' '.join(tokens)

    # & &
    tok_string = tok_string.replace('& &', '&&')

    # : :
    tok_string = tok_string.replace(': :', '::')

    # | |
    tok_string = tok_string.replace('| |', '||')
    tokens = tok_string.split()

    # float
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xe - xf, x . xE - xd
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+[eE] - \d+[fd] ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xE - x, x . xe - x, x . xe + x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+[Ee] [-+] \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xExd, x . xexf
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+[Ee]\d+[df] ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xex, x . xEx
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+[eE]\d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xf
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+f ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xF
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+F ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xd
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+d ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . xD
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. \d+D ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x_x . x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" [\d_]+ \. \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # . float
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \. \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # . xf, . xd, . xF
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \. \d+[fdF] ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # . x_x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \. \d[\d_]+\d ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . E - x, x . e - x, x . e + x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. [Ee] [-+] \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # x . f, x . F, x . d
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. [fFd] ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # float.
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+ \. ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # xe - xf, xE - xf
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+[eE] - \d+f ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # xe - x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+e - \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # xE - x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+E - \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # xe + x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" \d+e \+ \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # 0x1P - x, 0x1p - x
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" 0x1[Pp] - \d+ ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # 0x1 . 0p63f, 0x1 . 0p63
    tok_string = ' '.join(tokens)
    floats0 = re.findall(r" 0x1 \. 0p63f? ", tok_string)
    floats1 = []
    for f in floats0:
        floats1.append(' ' + ''.join(f.split()) + ' ')
    for i in range(len(floats0)):
        tok_string = tok_string.replace(floats0[i], floats1[i])
    tokens = tok_string.split()

    # \ \
    tok_string = ' '.join(tokens)
    tok_string = tok_string.replace("\\ \\", "\\\\")
    tokens = tok_string.split()

    # \ '
    tok_string = ' '.join(tokens)
    tok_string = tok_string.replace("\\\\", '<MASK>')
    tok_string = tok_string.replace("\ '", "\\\'")
    tok_string = tok_string.replace('<MASK>', "\\\\")
    tokens = tok_string.split()

    # \ "
    tok_string = ' '.join(tokens)
    tok_string = tok_string.replace("\\\\", '<MASK>')
    tok_string = tok_string.replace('\ "', '\\\"')
    tok_string = tok_string.replace('<MASK>', "\\\\")
    tokens = tok_string.split()

    # " string ", ' char '
    pos = 0
    for l in leaves:
        if l == 'character_literal':
            start = tokens.index("'", pos)
            end = tokens.index("'", start + 1)
            char = ' '.join(tokens[start: end + 1])
            char = char.replace('\\\\', '<MASK>')
            char = char.replace(' \ b ', ' \\b ')
            char = char.replace(' \ f ', ' \\f ')
            char = char.replace(' \ n ', ' \\n ')
            char = char.replace(' \ r ', ' \\r ')
            char = char.replace(' \ t ', ' \\t ')
            char = char.replace(' \ v ', ' \\v ')
            char = char.replace(' \ 0 ', ' \\0 ')
            char = char.replace(' \ ddd ', ' \\ddd ')
            char = char.replace(' \ uhhhh ', ' \\uhhhh ')
            char = char.replace('<MASK>', '\\\\')
            tokens[start] = char
            del tokens[start + 1: end + 1]
            pos = start + 1
        elif l == 'string_literal':
            start = tokens.index('"', pos)
            end = tokens.index('"', start + 1)
            string = ' '.join(tokens[start: end + 1])
            string = string.replace('\\\\', '<MASK>')
            string = string.replace(' \ b ', ' \\b ')
            string = string.replace(' \ f ', ' \\f ')
            string = string.replace(' \ n ', ' \\n ')
            string = string.replace(' \ r ', ' \\r ')
            string = string.replace(' \ t ', ' \\t ')
            string = string.replace(' \ v ', ' \\v ')
            string = string.replace(' \ 0 ', ' \\0 ')
            string = string.replace(' \ ddd ', ' \\ddd ')
            string = string.replace(' \ uhhhh ', ' \\uhhhh ')
            string = string.replace('<MASK>', '\\\\')
            tokens[start] = string
            del tokens[start + 1: end + 1]
            pos = start + 1

    # > >, < <, < =, > =, > > >, < < =, > > > =, > > =, = =, ! =, + =, - =, | =, * =, ^ =, & =, / =, + +, - >, . . .
    symbols = ['<', '>', '=', '+', '-', '.']
    targets = []
    for l in leaves:
        if any(s in l for s in symbols):
            targets.append(l)
    tok_string = '[TOKEN_SPLIT]' + '[TOKEN_SPLIT]'.join(tokens) + '[TOKEN_SPLIT]'
    pos = 0
    for t in targets:
        pos = tok_string.find('[TOKEN_SPLIT]' + ''.join([f'{x}[TOKEN_SPLIT]' for x in t]), pos)
        if pos == -1:
            print(' '.join(leaves))
            print(' '.join(tokens))
        assert pos != -1
        tok_string = tok_string[: pos] + '[TOKEN_SPLIT]' + t + '[TOKEN_SPLIT]' + tok_string[(pos + len(
            '[TOKEN_SPLIT]' + ''.join([f'{x}[TOKEN_SPLIT]' for x in t]))):]
        pos += len('[TOKEN_SPLIT]' + t)
    tok_string = tok_string[13: -13]
    tokens = tok_string.split('[TOKEN_SPLIT]')

    # " string ", ' char '
    if reserve_string:
        i = 0
        j = 0
        while i < len(tokens):
            if len(tokens[i]) > 1 and tokens[i][0] == "'" and tokens[i][-1] == "'":
                char = tokens[i]
                char = char.split()
                if i == len(tokens) - 1:
                    tokens = tokens[:i] + char
                else:
                    tokens = tokens[:i] + char + tokens[i + 1:]
                char_pos = leaves.index('character_literal', j)
                if char_pos == len(leaves) - 1:
                    leaves = leaves[:char_pos] + ['character_literal'] * len(char)
                    leaves_wi_idx = leaves_wi_idx[:char_pos] + [leaves_wi_idx[char_pos]] * len(char)
                else:
                    leaves = leaves[:char_pos] + ['character_literal'] * len(char) + leaves[char_pos + 1:]
                    leaves_wi_idx = leaves_wi_idx[:char_pos] + [leaves_wi_idx[char_pos]] * len(char) + leaves_wi_idx[char_pos + 1:]
                j = char_pos + len(char)
                i += len(char)
            elif len(tokens[i]) > 1 and tokens[i][0] == '"' and tokens[i][-1] == '"':
                string = tokens[i]
                string = string.split()
                if i == len(tokens) - 1:
                    tokens = tokens[:i] + string
                else:
                    tokens = tokens[:i] + string + tokens[i + 1:]
                string_pos = leaves.index('string_literal', j)
                if string_pos == len(leaves) - 1:
                    leaves = leaves[:string_pos] + ['string_literal'] * len(string)
                    leaves_wi_idx = leaves_wi_idx[:string_pos] + [leaves_wi_idx[string_pos]] * len(string)
                else:
                    leaves = leaves[:string_pos] + ['string_literal'] * len(string) + leaves[string_pos + 1:]
                    leaves_wi_idx = leaves_wi_idx[:string_pos] + [leaves_wi_idx[string_pos]] * len(string) + leaves_wi_idx[string_pos + 1:]
                j = string_pos + len(string)
                i += len(string)
            else:
                i += 1

    # ast type_identifier
    if leaves[: 6] == ['type_identifier', '<', 'type_identifier', ',', 'type_identifier', '>'] and tokens[0] == '<' and tokens[4] == '>':
        del leaves[0]
        del leaves_wi_idx[0]
    if leaves[: 10] == ['type_identifier', '<', 'type_identifier', ',', 'type_identifier', 'identifier', 'type_identifier', '.', 'type_identifier', '>'] and tokens[0] == '<' and tokens[8] == '>':
        del leaves[0]
        del leaves_wi_idx[0]

    # ast ERROR
    if 'ERROR' in leaves:
        pos = 0
        for i in range(1, len(leaves) - 1):
            if leaves[i] == 'ERROR' and leaves[i - 1] == '{' and leaves[i + 1] == 'if':
                pos = i
                break
        if pos != 0:
            del leaves[pos]
            del leaves_wi_idx[pos]

    i = 0
    while True:
        if i == len(leaves):
            break
        else:
            if leaves[i] in [';', ')', '}']:
                if (i < len(tokens) and leaves[i] != tokens[i]) or i >= len(tokens):
                    del leaves[i]
                    del leaves_wi_idx[i]
                else:
                    i += 1
            else:
                i += 1

    assert len(leaves) == len(leaves_wi_idx)
    for i in range(len(leaves)):
        assert leaves[i] == leaves_wi_idx[i][0]
    return leaves_wi_idx, tokens

def extract_docs(doc):
    # 删除中文
    if contain_chinese(doc):
        return None

    # 删除第一个@开头的行之后的全部内容
    doc = remain_beginning(doc)

    # 删除网址
    doc = remove_urls(doc)

    # 删除<pre></pre>之间的内容
    doc = remove_pres(doc)

    # 删除tags
    doc = remove_tags(doc)

    # 删除examples
    example_list = ['For example:', 'For Example:', 'Example:', 'example:', 'Sample Code:', 'Sample code:']
    for example in example_list:
        doc = remove_examples(doc, example)

    # 删除连续的- = / *，删除/* [ ]
    doc = re.sub(r'-+', '-', doc)
    doc = re.sub(r'=+', '=', doc)
    doc = re.sub(r'/+', '/', doc)
    doc = re.sub(r'\*+', '*', doc)
    doc = doc.replace('/*', ' ')
    doc = doc.replace('[', ' ')
    doc = doc.replace(']', ' ')
    doc = doc.strip()

    # 处理花括号内容
    doc = bracing(doc)

    # 去掉残留的@xxx
    doc = remove_at_symbol(doc)

    # nltk分句过滤
    doc = dot_filter(doc)

    # 处理驼峰和蛇形单词
    doc = _split_camel_case(doc)
    doc = ' '.join(doc)
    doc = _split_snake_case(doc)
    doc = ' '.join(doc)
    doc = ' '.join(doc.split())

    if len(doc) == 0:
        return None

    return doc.strip()

def extract_first_doc(doc):
    doc = extract_docs(doc)
    if doc is None:
        return None
    doc = doc.strip()
    while doc[0] == '.':
        doc = doc[1:].strip()
    doc = doc.split('.')
    doc = ' . '.join(doc)
    doc = doc.split()
    i = 0
    while i < len(doc) - 1:
        if doc[i] == '.' and doc[i + 1][0].isalpha() and doc[i + 1][0].isupper():
            doc = doc[:i + 1]
        i += 1
    doc = ' '.join(doc)

    return doc.strip()

def contain_chinese(string):
    for ch in string:
        if u'\u4e00' <= ch <= u'\u9fff':
            return True
    return False

def remove_urls(vTEXT):
    vTEXT = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', vTEXT, flags=re.MULTILINE)
    return (vTEXT)

def remove_pres(string):
    pre_l = re.search('<pre>', string)
    pre_r = re.search('</pre>', string)
    start = end = len(string)
    if pre_l is not None:
        start = pre_l.span()[0]
    if pre_r is not None:
        end = string.rindex('</pre>') + len('</pre>')
    string = string[:start] + ' ' + string[end:]
    return string

def remove_tags(string):
    string = re.sub(r'[<](.*?)[>]', ' ', string)
    return string

def remain_beginning(string):
    search = re.search('\n@', string)
    if search is not None:
        end = search.span()[0]
        string = string[:end]
    string = string.replace('\n', ' ')
    return string

def remove_examples(string, example):
    search = re.search(example, string)
    if search is not None:
        end = search.span()[0]
        string = string[:end]
    return string

def bracing(string):
    while re.search(r'[{](.*?)[}]', string) is not None:
        r = re.search(r'[{](.*?)[}]', string).span()
        text = string[r[0]:r[1]]
        text = text[1:-1]
        while re.search(r'[@](.*?)[ ]', text) is not None:
            start = re.search(r'[@](.*?)[ ]', text).span()[0]
            end = re.search(r'[@](.*?)[ ]', text).span()[1]
            text = text[:start] + ' ' + text[end:]
        while re.search(r'[(](.*?)[)]', text) is not None:
            start = re.search(r'[(](.*?)[)]', text).span()[0]
            end = re.search(r'[(](.*?)[)]', text).span()[1]
            text = text[:start] + ' ' + text[end:]
            break
        text = text.replace('#', ' ')
        symbols = re.findall(r'[^a-zA-Z]', text)
        symbols = list(set(symbols))
        for s in symbols:
            text = text.replace(s, ' ' + s + ' ')
        text = text.split()
        for i in range(len(text)):
            tok = text[i]
            tok = _split_camel_case(tok)
            for m in range(len(tok)):
                tok[m] = tok[m].lower()
            tok = ' '.join(tok)
            text[i] = tok
        text = ' '.join(text)
        text = text.split()
        for i in range(len(text)):
            tok = text[i]
            tok = _split_snake_case(tok)
            for m in range(len(tok)):
                tok[m] = tok[m].lower()
            tok = ' '.join(tok)
            text[i] = tok
        text = ' '.join(text)
        string = string[:r[0]] + text + string[r[1]:]
    return string

def remove_tails(string):
    string = string.strip()
    if re.search('\.', string) is not None:
        lastdot = string.rindex('.')
        tail = string[lastdot + 1:]
        words = re.sub(r'[^a-zA-Z]', ' ', tail)
        words = words.split()
        if len(tail) != 0 and tail[-1] == ':' and len(words) <= 2:
            string = string[:lastdot + 1]
    return string

def remove_at_symbol(string):
    while re.search(r'[@](.*?)[ ]', string) is not None:
        start = re.search(r'[@](.*?)[ ]', string).span()[0]
        end = re.search(r'[@](.*?)[ ]', string).span()[1]
        string = string[:start] + ' ' + string[end:]
    string = string.strip()
    return string

def dot_filter(string):
    symbols = re.findall(r'[^a-zA-Z]', string)
    symbols = list(set(symbols))
    for s in symbols:
        string = string.replace(s, ' ' + s + ' ')
    string = ' '.join(string.split())
    toks = string.split()
    while len(toks) != 0 and toks[0] == '.':
        del toks[0]
    i = 0
    while i < len(toks):
        if i < len(toks) - 2 and toks[i] == '.' and toks[i + 2] == '.':
            del toks[i]
        elif i < len(toks) - 1 and toks[i] == '.' and toks[i + 1][0].isalpha() and toks[i + 1][0].islower():
            del toks[i]
        else:
            i += 1
    string = ' '.join(toks)
    string = ' '.join(string.split())
    return string

def _split_snake_case(string):
    tokens = string.replace('_', '[IS_SNAKE]_[IS_SNAKE]')
    tokens = tokens.split('[IS_SNAKE]')
    while '' in tokens:
        tokens.remove('')
    return tokens

def _split_camel_case(string):
    tokens = []
    token = []
    for prev, char, next in zip(' ' + string, string, string[1:] + ' '):
        if _is_camel_case_boundary(prev, char, next):
            if token:
                tokens.append(''.join(token))
            token = [char]
        else:
            token.append(char)
    if token:
        tokens.append(''.join(token))
    return tokens

def _is_camel_case_boundary(prev, char, next):
    if prev.isdigit():
        return not char.isdigit()
    if char.isupper():
        return next.islower() or prev.isalpha() and not prev.isupper()
    return char.isdigit()

def _split_snake_and_camel_case(string):
    snake_tokens = _split_snake_case(string)
    tokens = []
    for snake_tok in snake_tokens:
        camel_tokens = _split_camel_case(snake_tok)
        tokens += camel_tokens
    return tokens

def code_parsing_wo_subtoken(code, reserve_string=False):
    code = remove_comments_and_docstrings(code, 'java')
    vertexs, edges, leaves, leaves_wi_idx, tokens = extract_leaves_and_tokens(code)
    nonterm_length = len(vertexs)
    leaves_wi_idx, tokens = aligning(leaves, leaves_wi_idx, tokens, reserve_string)
    tokens_wi_idx = [(tokens[i], i + len(vertexs)) for i in range(len(tokens))]
    for tok, i in tokens_wi_idx:
        vertexs[i] = tok
    assert len(leaves_wi_idx) == len(tokens_wi_idx)
    for i in range(len(leaves_wi_idx)):
        edges.append([leaves_wi_idx[i][1], tokens_wi_idx[i][1]])
    ast = {'vertexs': vertexs, 'edges': edges, 'nonterm_length': nonterm_length}
    return ast, tokens

def code_parsing_wi_subtoken(code, reserve_string=False):
    code = remove_comments_and_docstrings(code, 'java')
    vertexs, edges, leaves, leaves_wi_idx, tokens = extract_leaves_and_tokens(code)
    nonterm_length = len(vertexs)
    leaves_wi_idx, tokens = aligning(leaves, leaves_wi_idx, tokens, reserve_string)

    subtokens = []
    subleaves_wi_idx = []
    assert len(leaves_wi_idx) == len(tokens)
    if not reserve_string:
        for i in range(len(tokens)):
            tok = tokens[i]
            if tok[0] == tok[-1] and tok[0] in ['"', "'"] and leaves_wi_idx[i][0] in ['string_literal', 'character_literal']:
                tok = [tok]
            else:
                tok = _split_snake_and_camel_case(tok)
            subtokens += tok
            subleaves_wi_idx += [leaves_wi_idx[i]] * len(tok)
    else:
        for i in range(len(tokens)):
            tok = tokens[i]
            tok = _split_snake_and_camel_case(tok)
            subtokens += tok
            subleaves_wi_idx += [leaves_wi_idx[i]] * len(tok)

    subtokens_wi_idx = [(subtokens[i], i + len(vertexs)) for i in range(len(subtokens))]
    for subtok, i in subtokens_wi_idx:
        vertexs[i] = subtok
    assert len(subleaves_wi_idx) == len(subtokens_wi_idx)
    for i in range(len(subleaves_wi_idx)):
        edges.append([subleaves_wi_idx[i][1], subtokens_wi_idx[i][1]])
    subast = {'vertexs': vertexs, 'edges': edges, 'nonterm_length': nonterm_length}
    return subast, subtokens

# AST & TOKEN SEQ

def code_parsing(code, reserve_string=False):
    ast, tokens = code_parsing_wo_subtoken(code, reserve_string=reserve_string)
    subast, subtokens = code_parsing_wi_subtoken(code, reserve_string=reserve_string)
    return ast, tokens, subast, subtokens

# DOCSTRING

def docstring_parsing(docstring):
    doc_all = extract_docs(docstring)
    doc_fir = extract_first_doc(docstring)
    return doc_all, doc_fir